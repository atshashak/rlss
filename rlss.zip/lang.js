 var json = require('lang/en.json'); 
console.log(json);