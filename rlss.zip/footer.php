        
        <!--================ start footer Area  =================-->	
        <footer class="footer-area section_gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title"  style="font-size:24px;">संस्थान के बारे में</h6>
                            <p style="font-size:18px; color:white !important;">राजलक्ष्मी सेवा संस्थान के तत्वाधान में विगत कुछ वर्षो से आर्थिक रूप से पिछड़ी लड़कियों और महिलाओ के उत्थान के लिए वृहत पैमाने पर कार्य किया गया. राजलक्ष्मी सेवा संस्थान ब्युटिशियन ट्रेनिंग के कार्य को सफलतापूर्वक संचलित कर रहा है !</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title" style="font-size:24px;">मेनू </h6>
                            <div class="row">
                                <div class="col-4">
                                    <ul class="list">
                                        <li><a style="font-size:18px; color: white !important;" href="trust.php">मेंबर बनिए </a></li> <li><a style="font-size:18px; color: white !important;" href="event.php">आयोजन </a></li> <li><a style="font-size:18px; color: white !important;" href="volunteer.php">स्वयंसेवक </a></li> <li><a style="font-size:18px; color: white !important;" href="programs.php">कार्यक्रम </a></li>
                                      
                                    </ul>
                                </div>
                                <div class="col-4">
                                    <ul class="list">
                                        <li><a style="font-size:18px; color: white !important;" href="#">प्राइवेसी पालिसी</a></li> <li><a style="font-size:18px; color: white !important;" href="contact.php">सहायता  </a></li> <li><a style="font-size:18px; color: white !important;" href="contact.php">संपर्क </a></li>
                                     
                                    </ul>
                                </div>										
                            </div>							
                        </div>
                    </div>							
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title" style="font-size:24px;">साप्ताहिक समाचार पत्र </h6>
                            <p style="font-size:18px; color: white !important;">हम साप्ताहिक समाचार पत्र समुदाय को भेजते हैं ताकि वे जान सकें कि लोगों को आपके आसपास क्या चाहिए ताकि आप अच्छे के लिए तैयार हो सकें।</p>		
                            <div id="mc_embed_signup">
                                <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscribe_form relative">
                                    <div class="input-group d-flex flex-row">
                                        <input name="EMAIL" placeholder="Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address '" required="" type="email">
                                        <button class="btn sub-btn"><span class="lnr lnr-location"></span></button>		
                                    </div>									
                                    <div class="mt-10 info"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget instafeed">
                            <h6 class="footer_title">InstaFeed</h6>
                            <ul class="list instafeed d-flex flex-wrap">
                                <li><img src="img/instagram/Image-01.jpg" alt=""></li>
                                <li><img src="img/instagram/Image-02.jpg" alt=""></li>
                                <li><img src="img/instagram/Image-03.jpg" alt=""></li>
                                <li><img src="img/instagram/Image-04.jpg" alt=""></li>
                                <li><img src="img/instagram/Image-05.jpg" alt=""></li>
                                <li><img src="img/instagram/Image-06.jpg" alt=""></li>
                                <li><img src="img/instagram/Image-07.jpg" alt=""></li>
                                <li><img src="img/instagram/Image-08.jpg" alt=""></li>
                            </ul>
                        </div>
                    </div>						
                </div>
                <div class="border_line"></div>
                <div class="row footer-bottom d-flex justify-content-between align-items-center">
                    <p class="col-lg-8 col-md-8 footer-text m-0" style="font-size:18px; color: white !important;"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
© 2020 - राजलक्ष्मी सेवा संस्थान,सर्वाधिकार सुरक्षित 
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
                    <div class="col-lg-4 col-md-4 footer-social">
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                        <a href="#"><i class="fa fa-instagram"></i></a>
                        <a href="#"><i class="fa fa-whatsapp"></i></a>
                    </div>
                </div>
            </div>
        </footer>
		<!--================ End footer Area  =================-->
        
        
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/jquery-3.2.1.min.js"></script>
        <script src="js/popper.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/stellar.js"></script>
        <script src="vendors/lightbox/simpleLightbox.min.js"></script>
        <script src="vendors/nice-select/js/jquery.nice-select.min.js"></script>
        <script src="vendors/isotope/imagesloaded.pkgd.min.js"></script>
        <script src="vendors/isotope/isotope-min.js"></script>
        <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="js/mail-script.js"></script>
        <script src="js/theme.js"></script>
    </body>
</html>