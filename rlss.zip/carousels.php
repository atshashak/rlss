     <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
         <!--
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
-->
         <div class="carousel-inner">


             <div class="carousel-item active">
                 <img class="d-block w-100" src="img/banner/corona.jpg" alt="Second slide">
                 <div class="carousel-caption d-flex justify-content-center align-items-center flex-column" style="height: 100%;">
                     <h5 style="font-size: 30px !important;">कार्यक्रम</h5><br>
                     <p class="text-white" style="font-size: 58px !important; line-height: 72px !important;">कोरोना वायरस हेल्प कैंप <br> गरीबों और जरुरतमंदो की मदद्त के लिए हमसे जुड़ें </p>
                     <div>

                         <a href="contact.php" class="genric-btn primary text-dark">संपर्क करें</a> &nbsp;
                         <a href="donatenow.php" class="genric-btn success">डोनेट करें </a>

                     </div>


                 </div>


             </div>

             <div class="carousel-item">
                 <img class="d-block w-100" src="img/banner/home-banner.jpg" alt="First slide">
                 <div class="carousel-caption d-flex justify-content-center align-items-center flex-column" style="height: 100%;">
                     <h5 style="font-size: 30px !important;">आयोजन</h5><br>
                     <p class="text-white" style="font-size: 58px !important; line-height: 72px !important;">उत्कृष्ट योगदान के लिए राजलक्ष्मी सेवा संस्थान ने किया विशिष्ट महिलाओं का सम्मान</p>
                     <div>

                         <a href="#" class="genric-btn primary text-dark">और जानें</a> &nbsp;
                         <a href="#" class="genric-btn success">डोनेट करें </a>

                     </div>


                 </div>
             </div>

             <!--
    <div class="carousel-item">
      <img class="d-block w-100" src="img/banner/home-banner.jpg" alt="Third slide">
    </div>
-->
         </div>
         <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
             <span class="carousel-control-prev-icon" aria-hidden="true"></span>
             <span class="sr-only">Previous</span>
         </a>
         <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
             <span class="carousel-control-next-icon" aria-hidden="true"></span>
             <span class="sr-only">Next</span>
         </a>
     </div>